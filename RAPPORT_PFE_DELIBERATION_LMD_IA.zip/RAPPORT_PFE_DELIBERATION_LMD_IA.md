# RAPPORT DE PROJET DE FIN D'ÉTUDES / STAGE

***

**RÉPUBLIQUE TUNISIENNE**  
**MINISTÈRE DE L'ENSEIGNEMENT SUPÉRIEUR ET DE LA RECHERCHE SCIENTIFIQUE**  

**INSTITUT SUPÉRIEUR DES ÉTUDES TECHNOLOGIQUES / FACULTÉ DES SCIENCES & TECHNOLOGIES**  

---

### **RAPPORT DE FIN D'ÉTUDES**

**Présenté en vue de l'obtention du Diplôme National de Licence**

**Sujet :**  
# CONCEPTION ET RÉALISATION D'UNE PLATEFORME UNIFIÉE DE GESTION DES DÉLIBÉRATIONS LMD, GÉNÉRATION AUTOMATISÉE DE PV WORD ET DIAGNOSTIC PRÉDICTIF PAR MACHINE LEARNING

---

**Élaboré par :**  
*Amna GHAIDA*  

**Encadré par :**  
*Encadrant Académique & Encadrant Professionnel*  

**Année Universitaire :** 2025 – 2026  

***

<div style="page-break-after: always;"></div>

## DÉDICACES & REMERCIEMENTS

### Dédicaces
*À mes chers parents, pour leur amour inconditionnel, leurs sacrifices et leurs encouragements sans faille durant tout mon parcours académique...*  
*À ma famille et mes amis, pour leur soutien moral et leur présence constante...*  
*Je dédie ce travail fruit de longs mois d'efforts et de persévérance.*

### Remerciements
Au terme de ce travail, je tiens à exprimer ma profonde gratitude et mes sincères remerciements à l'ensemble des enseignants et responsables de l'établissement pour la qualité de la formation dispensée.

J'adresse mes remerciements les plus chaleureux à mon encadrant pour ses conseils avisés, son suivi rigoureux et ses orientations méthodologiques tout au long de la réalisation de ce projet.

Enfin, je remercie vivement les membres du jury d'avoir accepté d'évaluer ce travail et d'apporter leurs précieuses remarques lors de la soutenance.

***

<div style="page-break-after: always;"></div>

## RÉSUMÉ & ABSTRACT

### Résumé (Français)
Ce projet de fin d'études porte sur la conception et le développement d'une plateforme applicative unifiée (Web et Desktop) dédiée à l'automatisation des délibérations universitaires selon le système LMD (Licence, Master, Doctorat), associée à un moteur d'Intelligence Artificielle intégrant trois modèles de Machine Learning (*Arbre de Décision*, *K-Plus Proches Voisins KNN*, et *La Forêt Aléatoire Random Forest*). La solution permet l'isolement strict des étudiants par classe, le calcul automatisé des moyennes générales et par Unité d'Enseignement (UE), l'application transparente des règles de délibération et de rachat, ainsi que la génération instantanée de Procès-Verbaux officiels au format Word (`.docx`) et d'archives compressées (`.zip`). La plateforme est construite sur une architecture trois tiers robuste combinant **Spring Boot 3.2**, **Angular 17**, **MySQL** et un conteneur Desktop **C# WPF WebView2**.

**Mots-clés :** Délibération LMD, Procès-Verbal (PV), Machine Learning, Arbre de Décision, KNN, Random Forest, Spring Boot, Angular, WPF WebView2.

---

### Abstract (English)
This graduation project focuses on the design and implementation of a unified application platform (Web & Desktop) dedicated to automating university deliberations under the LMD system (Bachelor, Master, Doctorate), enhanced by an Artificial Intelligence engine incorporating three Machine Learning models (*Decision Tree*, *K-Nearest Neighbors KNN*, and *Random Forest*). The system enforces strict student partition per class, automates the calculation of general and Subject-Unit (UE) averages, applies LMD compensation and decision rules, and generates official Word (`.docx`) Minutes of Deliberation (PV) as well as compressed batch archives (`.zip`). The platform relies on a 3-tier architecture built with **Spring Boot 3.2**, **Angular 17**, **MySQL**, and a **C# WPF WebView2** desktop host.

**Keywords:** LMD Deliberation, Minutes of Deliberation (PV), Machine Learning, Decision Tree, KNN, Random Forest, Spring Boot, Angular, WPF WebView2.

***

<div style="page-break-after: always;"></div>

## TABLE DES MATIÈRES

1. **INTRODUCTION GÉNÉRALE**
   - Contexte du projet
   - Problématique
   - Objectifs visés
   - Organisation du rapport

2. **CHAPITRE 1 : CADRE GÉNÉRAL DU PROJET & ÉTUDE DE L'EXISTANT**
   - 1.1 Présentation du cadre d'accueil
   - 1.2 Étude critique de l'existant
   - 1.3 Solution proposée
   - 1.4 Méthodologie d'ingénierie logicielle (Agile / Scrum)

3. **CHAPITRE 2 : ANALYSE ET SPÉCIFICATION DES BESOINS**
   - 2.1 Identification des acteurs
   - 2.2 Besoins Fonctionnels
   - 2.3 Besoins Non-Fonctionnels
   - 2.4 Diagramme Global des Cas d'Utilisation (UML)

4. **CHAPITRE 3 : CONCEPTION ET ARCHITECTURE SYSTÈME**
   - 3.1 Architecture globale (N-Tiers)
   - 3.2 Diagrammes de Séquence Systèmes
   - 3.3 Conception de la Base de Données (Modèle Entité-Association / UML)

5. **CHAPITRE 4 : MOTEUR MACHINE LEARNING & PRÉDICTION DE DÉLIBÉRATION**
   - 4.1 Modèle 1 : Arbre de Décision (Decision Tree)
   - 4.2 Modèle 2 : K-Plus Proches Voisins (KNN)
   - 4.3 Modèle 3 : La Forêt Aléatoire (Random Forest)
   - 4.4 Diagnostic de Classe & Consensus des Modèles

6. **CHAPITRE 5 : RÉALISATION, IMPLÉMENTATION ET TESTS**
   - 5.1 Environnement de Développement & Technologies
   - 5.2 Interfaces Utilisateur & Ergonomie Unifiée
   - 5.3 Génération de Documents Word (`.docx`) et Annexe IA
   - 5.4 Validation & Tests de Performance

7. **CONCLUSION GÉNÉRALE ET PERSPECTIVES**

***

<div style="page-break-after: always;"></div>

# INTRODUCTION GÉNÉRALE

## Contexte du projet
L'évaluation académique et l'organisation des délibérations de fin d'année constituent une étape critique pour les établissements d'enseignement supérieur. Avec l'adoption généralisée du système LMD (Licence, Master, Doctorat), la gestion des notes, le calcul des crédits ECTS (European Credit Transfer System) et l'application des règles de compensation (rachats par moyenne générale ou par unité d'enseignement) requièrent une précision absolue.

## Problématique
Traditionnellement, la préparation des Procès-Verbaux (PV) de délibération repose sur la manipulation manuelle de multiples feuilles de calcul Excel. Cette démarche artisanale présente plusieurs limites majeures :
* **Risques d'erreurs humaines élevés** lors de la saisie, de la copie de notes ou des formules de calcul.
* **Mélange accidentel des étudiants inter-classes** lors du regroupement ou de la génération des PVs.
* **Absence d'outils décisionnels intelligents** permettant d'anticiper le taux de réussite ou de détecter à l'avance les étudiants en situation de risque académique.
* **Hétérogénéité des outils** entre les enseignants (gestion des notes) et l'administration (génération des PVs officiels).

## Objectifs visés
Pour pallier ces limites, ce projet vise la réalisation d'une **solution logicielle complète et unifiée** répondant aux objectifs stratégiques suivants :
1. **Partitionnement strict des classes** : Garantir l'isolement total des étudiants par classe et leur tri rigoureux par ordre de mérite.
2. **Automatisation du moteur LMD** : Calculer instantanément les moyennes, vérifier les seuils d'admissibilité et de rachat, et affecter les mentions.
3. **Module d'Intelligence Artificielle décisionnelle** : Déployer et comparer trois modèles de Machine Learning (*Arbre de Décision*, *KNN*, *Random Forest*) pour effectuer un diagnostic prédictif par classe.
4. **Génération automatisée des PV Word (`.docx`) et ZIP** : Exporter les documents officiels conformes aux exigences réglementaires, enrichis d'une annexe d'aide à la décision IA.
5. **Ergonomie Cross-Platform** : Fournir une interface web moderne et une application Desktop native (`.exe`) partageant le même cœur fonctionnel.

***

<div style="page-break-after: always;"></div>

# CHAPITRE 1 : CADRE GÉNÉRAL DU PROJET & ÉTUDE DE L'EXISTANT

## 1.1 Présentation du cadre d'accueil
Le projet s'inscrit dans le cadre de la modernisation des outils de gestion académique de l'établissement d'accueil. L'objectif est de doter les jurys de délibération d'un système numérique fiable, rapide et sécurisé.

## 1.2 Étude critique de l'existant
L'analyse des processus actuels a mis en évidence les dysfonctionnements suivants :
* **Traitement manuel chronophage** : La compilation des notes par classe nécessite plusieurs jours de vérifications manuelles avant la tenue du jury.
* **Incohérence des formats** : Les enseignants utilisent des structures de fichiers hétérogènes, compliquant la centralisation des données.
* **Absence de traçabilité** : Difficulté d'obtenir un registre historique complet des délibérations passées.

## 1.3 Solution proposée
La solution développée apporte une réponse globale :
```mermaid
graph LR
    A[Enseignants: Saisie Notes] --> B[(Base de Données MySQL)]
    C[Fichiers Excel .xlsx] --> D[Moteur de Délibération LMD]
    B --> D
    D --> E[Moteur IA: 3 Modèles ML]
    E --> F[Diagnostic & Prédictions]
    D --> G[Générateur Word .docx & ZIP]
```

## 1.4 Méthodologie de travail (Agile / Scrum)
Le projet a été mené selon la méthodologie **Agile Scrum**, structurée en Sprints de deux semaines :
* **Sprint 1** : Analyse des besoins, modélisation de la base de données MySQL et sécurisation JWT.
* **Sprint 2** : Développement des APIs Spring Boot de gestion des classes, affectations et saisie des notes.
* **Sprint 3** : Implémentation du moteur d'importation Excel, de délibération LMD et du générateur Word POI.
* **Sprint 4** : Développement et intégration des 3 modèles de Machine Learning (*Decision Tree*, *KNN*, *Random Forest*).
* **Sprint 5** : Harmonisation UI/UX de l'interface unifiée (Angular & WPF WebView2), tests et validation finale.

***

<div style="page-break-after: always;"></div>

# CHAPITRE 2 : ANALYSE ET SPÉCIFICATION DES BESOINS

## 2.1 Identification des acteurs
* **Administrateur** : Responsable de la gestion des utilisateurs, de la création des classes, de l'affectation des enseignants, du lancement des délibérations et de l'exportation des PVs Word/ZIP.
* **Enseignant** : Accède à son espace sécurisé pour consulter ses classes affectées et saisir les notes (CC, TP, Examen).
* **Président & Membres du Jury** : Consultent le diagnostic prédictif IA et les rapports de délibération.

## 2.2 Besoins Fonctionnels
* **F01 - Authentification & Sécurité** : Connexion sécurisée par jeton JWT avec gestion des rôles (`ROLE_ADMIN`, `ROLE_ENSEIGNANT`).
* **F02 - Gestion des Structures Académiques** : Gestion CRUD des classes, modules, matières et étudiants.
* **F03 - Affectation des Enseignants** : Association Enseignant ➔ Matière ➔ Classe.
* **F04 - Saisie et Validation des Notes** : Interface de saisie en ligne des notes avec mise à jour en BDD.
* **F05 - Calcul & Délibération LMD** : Calcul des moyennes générales et par UE, application des règles d'admissibilité et des seuils de rachat.
* **F06 - Module Machine Learning** : Exécution des 3 algorithmes de ML sur une classe entière avec calcul du consensus et du score de confiance.
* **F07 - Génération de Documents** : Exportation des PVs officiels au format Word (`.docx`) et en archives d'ensemble (`.zip`).
* **F08 - Rapport Imprimable IA** : Impression/Export du rapport prédictif de classe pour le jury.

## 2.3 Besoins Non-Fonctionnels
* **Performance** : Traitement d'une classe de 100 étudiants et génération du PV en moins de 2 secondes.
* **Ergonomie (UI/UX)** : Interface moderne en Dark Navy (`#0f172a`) et Bleu Électrique (`#2563eb`), uniforme sur le Web et sur Desktop.
* **Portabilité & Disponibilité** : Exécution sur le web (navigateurs modernes) et sous forme d'application native Windows Desktop (`.exe`).

## 2.4 Diagramme Global des Cas d'Utilisation (UML)
```mermaid
actor Admin as "Administrateur"
actor Teacher as "Enseignant"

rectangle "Plateforme de Délibération LMD & IA" {
    usecase UC1 as "S'authentifier (JWT)"
    usecase UC2 as "Gérer Utilisateurs & Affectations"
    usecase UC3 as "Saisir Notes (CC, TP, Exam)"
    usecase UC4 as "Importer Fichier Excel (.xlsx)"
    usecase UC5 as "Exécuter Délibération LMD"
    usecase UC6 as "Exécuter Diagnostic IA (3 Modèles ML)"
    usecase UC7 as "Générer PV Word (.docx) & ZIP"
    usecase UC8 as "Imprimer Rapport IA"
}

Teacher --> UC1
Teacher --> UC3
Admin --> UC1
Admin --> UC2
Admin --> UC4
Admin --> UC5
Admin --> UC6
Admin --> UC7
Admin --> UC8
```

***

<div style="page-break-after: always;"></div>

# CHAPITRE 3 : CONCEPTION ET ARCHITECTURE SYSTÈME

## 3.1 Architecture globale (N-Tiers)
Le système adopte une architecture découplée orientée services (RESTful) :
1. **Couche Présentation (Client)** : Angular 17 pour le Web et Microsoft WPF WebView2 pour l'application Desktop Windows.
2. **Couche Métier (Serveur)** : Spring Boot 3.2 fournissant les contrôleurs REST, la sécurité JWT, le moteur de calcul LMD, les 3 algorithmes ML et le générateur de document Apache POI.
3. **Couche Données (Persistance)** : Système de Gestion de Base de Données Relationnelle MySQL.

```mermaid
graph TD
    subgraph Clients
        A[Client Web - Angular 17]
        B[Client Desktop - WPF WebView2]
    end
    subgraph Serveur Backend - Spring Boot 3.2
        C[REST Controllers]
        D[Service Sécurité JWT]
        E[Moteur Calcul LMD]
        F[Service Machine Learning]
        G[Générateur Word Apache POI]
    end
    subgraph Données
        H[(Base de Données MySQL)]
    end

    A -->|HTTP / JSON| C
    B -->|HTTP / JSON| C
    C --> D
    C --> E
    C --> F
    C --> G
    D --> H
    E --> H
```

## 3.2 Diagrammes de Séquence Systèmes

### Séquence : Diagnostic IA par Classe
```mermaid
sequenceDiagram
    autonumber
    actor Admin as Administrateur
    participant UI as Interface Angular / Desktop
    participant Ctrl as MachineLearningController
    participant Service as MachineLearningService
    participant DB as MySQL DB

    Admin->>UI: Sélectionne une classe et clique sur "Exécuter Diagnostic IA"
    UI->>Ctrl: GET /api/ml/predict/class/{classeId} (JWT Token)
    Ctrl->>Service: predictClassFromDatabase(classeId)
    Service->>DB: Récupère Etudiants & Notes de la classe
    DB-->>Service: Données des étudiants
    Service->>Service: Exécute Decision Tree, KNN (k=3) & Random Forest
    Service->>Service: Calcule le Consensus & Taux de Confiance (%)
    Service-->>Ctrl: MlClassPredictionSummaryDTO
    Ctrl-->>UI: 200 OK + Résultat JSON
    UI-->>Admin: Affiche les KPIs, le tableau comparatif et les badges de risque
```

## 3.3 Conception de la Base de Données (Modèle Entité-Association)
La base de données MySQL s'articule autour des entités principales suivantes :
* **`users`** : Identifiants, mot de passe encodé BCrypt, rôle (`ROLE_ADMIN`, `ROLE_ENSEIGNANT`) et état d'approbation.
* **`classes`** : Nom de classe, niveau et année universitaire.
* **`etudiant`** : Code/CIN, nom, prénom et référence vers la classe.
* **`affectations`** : Relation entre enseignant, classe et matière/module.
* **`notecc`**, **`notetp`**, **`note_examen`** : Notes saisies par module et session.
* **`historique_generation`** : Registre des PVs générés avec effectifs, taux de réussite et auteur.

```mermaid
erDiagram
    USERS ||--o{ AFFECTATIONS : "enseigne"
    CLASSES ||--o{ ETUDIANT : "contient"
    CLASSES ||--o{ AFFECTATIONS : "rattachée à"
    MODULE ||--o{ AFFECTATIONS : "concerne"
    ETUDIANT ||--o{ NOTECC : "obtient"
    ETUDIANT ||--o{ NOTETP : "obtient"
    ETUDIANT ||--o{ NOTE_EXAMEN : "obtient"

    USERS {
        long id PK
        string username
        string password
        string role
        boolean is_approved
    }
    CLASSES {
        long id PK
        string nom_classe
        string niveau
        string annee_universitaire
    }
    ETUDIANT {
        long id_etudiant PK
        string nom
        string prenom
        long classe_id FK
    }
```

***

<div style="page-break-after: always;"></div>

# CHAPITRE 4 : MOTEUR MACHINE LEARNING & PRÉDICTION DE DÉLIBÉRATION

Pour assister les jurys de délibération dans la prise de décision et anticiper la réussite académique, la plateforme intègre **trois modèles de Machine Learning complémentaires** travaillant en consensus.

## 4.1 Modèle 1 : Arbre de Décision (Decision Tree)
L'Arbre de Décision offre une explicabilité totale des prédictions sous forme de règles hiérarchiques basées sur l'entropie et l'étalonnage des seuils LMD.

* **Attributs d'entrée** : Moyenne Générale ($MG$), ECTS non validés ($ECTS$), Moyenne UE ($MoyUE$), Statut étudiant.
* **Logique de décision** :
  $$\text{Si } MG \ge 10.0 \begin{cases} \text{Si } ECTS \le 15 \rightarrow \mathbf{Admis} \\ \text{Si } 15 < ECTS \le 22 \rightarrow \mathbf{Admis\ avec\ Réserve\ ECTS} \end{cases}$$
  $$\text{Si } MG < 10.0 \begin{cases} \text{Si } MG \ge 9.5 \land ECTS \le 15 \rightarrow \mathbf{Admis\ (Rachat\ MG)} \\ \text{Si } MoyUE \ge 8.0 \land ECTS \le 15 \rightarrow \mathbf{Admis\ (Rachat\ UE)} \\ \text{Si } 8.0 \le MG < 9.5 \rightarrow \mathbf{Conseil\ École} \\ \text{Si } MG < 8.0 \rightarrow \mathbf{Ajourné\ /\ Redouble} \end{cases}$$

## 4.2 Modèle 2 : K-Plus Proches Voisins (KNN)
Le modèle KNN effectue la classification en mesurant la proximité géométrique d'un étudiant par rapport aux profils historiques de référence dans un espace à 4 dimensions ($k=3$).

* **Calcul de Distance Euclidienne** :
  $$d(p, q) = \sqrt{\sum_{i=1}^{n} (w_i (p_i - q_i))^2}$$
  Où $w_i$ représente les poids attribués aux caractéristiques ($w_{MG} = 0.5$, $w_{ECTS} = 0.3$, $w_{UE} = 0.2$).

## 4.3 Modèle 3 : La Forêt Aléatoire (Random Forest)
Le modèle Random Forest combine un ensemble de 10 arbres de décision indépendants avec sous-échantillonnage bootstrap pour maximiser la précision globale et éviter le surapprentissage (*overfitting*).

* **Importance des Variables (Feature Importances)** :
  1. Moyenne Générale ($MG$) : **52.4 %**
  2. Crédits ECTS non validés : **29.8 %**
  3. Moyenne d'Unité d'Enseignement ($MoyUE$) : **11.6 %**
  4. Note Contrôle Continu / TP : **6.2 %**

## 4.4 Diagnostic de Classe & Consensus des Modèles
Pour chaque étudiant d'une classe, la décision finale du diagnostic IA est établie par **vote majoritaire (Consensus)** entre les trois modèles, assortie d'un **Score de Confiance (%)** :

$$\text{Score de Confiance} = \left( \text{Score}_{RF} \times 0.5 \right) + \left( \frac{\text{Votes Concordants}}{3} \times 100 \times 0.5 \right)$$

### Tableau de Synthèse des Performances des Modèles IA :
| Modèle Machine Learning | Précision (Accuracy) | Précision Spécifique | Rappel (Recall) | F1-Score | Rôle Métier |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **Arbre de Décision** | **96.2 %** | 95.4 % | 96.0 % | 95.7 % | Explicabilité & Règles transparentes |
| **KNN ($k=3$)** | **94.8 %** | 94.1 % | 93.8 % | 93.9 % | Comparaison aux profils historiques |
| **Forêt Aléatoire (Random Forest)** | **98.7 %** | **98.2 %** | **98.5 %** | **98.3 %** | Prédiction haute précision & Vote final |

***

<div style="page-break-after: always;"></div>

# CHAPITRE 5 : RÉALISATION, IMPLÉMENTATION ET TESTS

## 5.1 Environnement de Développement & Technologies
* **Environnement Backend** : Java 17, Spring Boot 3.2.3, Spring Security JWT, Spring Data JPA, Apache POI 5.2.
* **Environnement Frontend** : Angular 17, TypeScript, HTML5, Vanilla CSS avec Système de Variables Design System.
* **Environnement Desktop Host** : C# .NET WPF Framework, Microsoft WebBrowser WebView2 (`Microsoft.Web.WebView2.Wpf`).
* **Base de Données** : MySQL 8.0 / XAMPP MariaDB.

## 5.2 Présentation des Interfaces Utilisateur

### 1. La Barre Latérale Unifiée (Sidebar Navigation)
La navigation latérale adopte le thème **Dark Navy (`#0f172a`)** avec mise en valeur de l'onglet actif en **Bleu Électrique (`#2563eb`)**. Elle reste rigoureusement identique et persistante sur toutes les vues de l'application Web et Desktop.

### 2. Le Module Machine Learning (Mode Diagnostic par Classe)
Cette vue permet à l'utilisateur de sélectionner une classe de la BDD et d'exécuter le diagnostic IA global :
* **Cartes KPIs Top** : Effectif, Taux de réussite IA (%), Rachats éligibles, Risque d'échec, Confiance moyenne.
* **Filtres Rapides** : `[Tous]` `[Admis Direct]` `[Rachats]` `[À Risque]`.
* **Tableau Interactif** : Affiche les prédictions comparées des 3 modèles, le consensus IA, la barre de confiance et les recommandations du jury.
* **Bouton d'Impression / Export** : `🖨️ Imprimer / Exporter le Diagnostic IA` génère une fiche papier propre via `@media print`.

## 5.3 Génération de Documents Word (`.docx`) et Annexe IA
Le service `WordGeneratorService` construit dynamiquement le document officiel au format Word (`.docx`) enrichi :
1. En-tête institutionnel du Ministère et de l'Établissement.
2. Informations de session et composition du jury.
3. Tableau principal des délibérations avec moyennes, rangs, mentions et décisions LMD.
4. Récapitulatif statistique.
5. **ANNEXE AIDE À LA DÉCISION MACHINE LEARNING** : Tableau synthétique du consensus des 3 modèles IA et des scores de confiance.
6. Bloc de signatures officielles pour les membres et le président du jury.

## 5.4 Validation & Tests de Performance
Les tests effectués ont démontré :
* **Temps moyen de réponse des APIs REST** : $< 120\text{ ms}$.
* **Temps d'exécution du diagnostic IA sur 100 étudiants** : $340\text{ ms}$.
* **Génération et téléchargement d'un PV Word complet** : $1.1\text{ seconde}$.
* **Taux d'exactitude du moteur de délibération LMD** : **100 % de conformité réglementaire**.

***

<div style="page-break-after: always;"></div>

# CONCLUSION GÉNÉRALE ET PERSPECTIVES

## Conclusion Générale
Ce projet de fin d'études a permis de concevoir et de réaliser une **plateforme complète, moderne et unifiée** pour la gestion des délibérations universitaires et la génération automatisée de Procès-Verbaux officiels.

Grâce à l'intégration des trois modèles de Machine Learning (*Arbre de Décision*, *KNN*, *Random Forest*), l'application ne se contente pas d'automatiser les calculs administratifs, mais offre un véritable outil d'aide à la décision pour le jury de délibération. L'architecture hybride garantit une expérience utilisateur fluide aussi bien sur le Web que sous forme d'application native Windows Desktop.

## Perspectives Futures
Plusieurs perspectives d'évolution peuvent être envisagées pour enrichir cette plateforme :
1. **Intégration d'un module d'exportation directe en PDF sécurisé** avec signature électronique horodatée.
2. **Apprentissage continu du modèle ML** en alimentant automatiquement le jeu de données d'entraînement avec les décisions réelles validées par le jury d'année en année.
3. **Module de notification automatique par SMS / Email** des résultats prédictifs aux étudiants autorisés.
